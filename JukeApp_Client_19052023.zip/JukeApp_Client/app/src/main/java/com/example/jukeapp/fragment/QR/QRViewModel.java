package com.example.jukeapp.fragment.QR;

import androidx.lifecycle.ViewModel;

public class QRViewModel extends ViewModel {
}
