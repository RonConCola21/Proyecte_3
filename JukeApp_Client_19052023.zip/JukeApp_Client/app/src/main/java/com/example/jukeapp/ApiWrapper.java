package com.example.jukeapp;

public class ApiWrapper {
    public static String getApiUrl() {
        return "http://api.spotify.com";
    }
}
