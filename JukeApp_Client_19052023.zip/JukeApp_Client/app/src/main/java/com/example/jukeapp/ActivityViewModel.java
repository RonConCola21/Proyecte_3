package com.example.jukeapp;

import androidx.lifecycle.ViewModel;

public class ActivityViewModel extends ViewModel {

}
