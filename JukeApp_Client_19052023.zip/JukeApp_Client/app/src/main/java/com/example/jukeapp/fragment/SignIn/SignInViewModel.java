package com.example.jukeapp.fragment.SignIn;

import androidx.lifecycle.ViewModel;

public class SignInViewModel extends ViewModel {
}
