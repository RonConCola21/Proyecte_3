package com.example.jukeapp.fragment.LogIn;

import androidx.lifecycle.ViewModel;

public class LogInViewModel extends ViewModel {
}
