package com.example.jukeapp.fragment.PlaybackQueue;

public class PlayBackQueueViewModel extends androidx.lifecycle.ViewModel {

}
